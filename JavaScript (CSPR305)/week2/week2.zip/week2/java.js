
/**
let fname="";
let lname='';
fname=window.prompt('enter your first name ');
if (fname=="jonathan")
{

  document.write("you guessed it right");
}
else{
document.write("Nah!!!!!");

}
**/
let age;
age=294;
if (age<=18){
document.write("you are a kid");

}
else if (age>18 && age<51){
  document.write("you are an adult");
}
else{
  document.write("hello elderly");
}
